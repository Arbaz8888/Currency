import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector, TypedUseSelectorHook } from 'react-redux';
import { fetchExchangeRates} from '../store/exchangeSlice';
import { RootState, AppDispatch } from '../store';




const ExchangeWidget: React.FC = () => {
    const dispatch = useDispatch<AppDispatch>();
    const [base, setBase] = useState('USD');
    const [targets, setTargets] = useState(['EUR', 'GBP', 'JPY']);
    const [autoUpdate, setAutoUpdate] = useState(false);

    const exchange = useSelector((state: RootState) => state.exchange);
    const { rates, loading, error } = exchange;


    useEffect(() => {
        dispatch(fetchExchangeRates({ base, targets }));
    }, [base, targets, dispatch]);

    useEffect(() => {
        let interval: NodeJS.Timeout | null = null;

        if (autoUpdate) {
            interval = setInterval(() => {
                dispatch(fetchExchangeRates({ base, targets }));
            }, 60000); // Update every minute
        }

        return () => {
            if (interval) {
                clearInterval(interval);
            }
        };
    }, [autoUpdate, base, targets, dispatch]);

return (
    <div style={{ border: "1 px solid gray", padding: 16, marginBottom: 16}}> 
    <h3>Exchange Rates - Base: {base}</h3>

    <button onClick={() => setAutoUpdate(!autoUpdate)}>
        {autoUpdate ? "Stop Auto Update" : "Enable Auto Update"}
    </button>

    {loading ? (
        <p>Loading...</p>
    ) : error ? (
        <p style={{ color: 'red' }}>Error: {error}</p>
    ) : (
        <ul>
            {targets.map(target => (
                <li key={target}>
                    {base} {target}: {rates[target]}
                </li>
            ))}
        </ul>
    )}

    </div>
)
};
//

export default ExchangeWidget;
export { ExchangeWidget }; // Export the component for use in other files






