import React, {useState, ChangeEvent} from "react";
import { useSelector, useDispatch } from "react-redux";
import type { RootState, AppDispatch } from "../store";

import {
    addWidget,
    removeWidget,
} from "../store/widgetSlice";
import { ExchangeWidget } from "./ExchangeWidget";

const WidgetList: React.FC = () => {      
    const dispatch = useDispatch<AppDispatch>();
    // Adjust this line to select the correct property from your Redux state.
    // For example, if your widgets are stored in state.widget.widgets:
    // const widgets = useSelector((state: RootState) => state.widget.widgets);

    // If you intended to use the 'exchange' slice, but it doesn't have 'items', 
    // you might want to use 'rates' or another property:
    // Ensure widgets is an array; adjust selector as needed for your state shape
    const widgets = useSelector((state: RootState) => state.widget.items || []);

    // If you have a separate widgetSlice, use that instead:
    // const widgets = useSelector((state: RootState) => state.widget.items);
    const [baseCurrency, setBaseCurrency] = useState('USD');
    const [targetCurrencies, setTargetCurrencies] = useState(['EUR', 'GBP', 'JPY']);

    const handleAddWidget = () => {
        dispatch(addWidget({ base: baseCurrency, targets: targetCurrencies }));
    };

    const handleRemoveWidget = (index: number) => {
        dispatch(removeWidget(index));
    };

    return (

        <div>
            <h1>Exchange Rate Widgets</h1>
            <div> 
                <label>Base Currency:</label>
                <input
                    type="text"
                    value={baseCurrency}
                    onChange={(e) => setBaseCurrency(e.target.value.toUpperCase())}
                />
                 <label>Target Currencies:</label>
                <input
                    type="text"
                    value={targetCurrencies.join(", ")}
                    onChange={(e) => setTargetCurrencies(e.target.value.split(", ").map(curr => curr.trim().toUpperCase()))}
                />
                <label> <button onClick={handleAddWidget}>Add Widget</button></label>
            </div>
        </div>

    );
}