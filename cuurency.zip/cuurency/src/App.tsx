import React from 'react';
import { ExchangeWidget } from './components/ExchangeWidget';
import { WidgetList } from "./components/WidgetList";

const App: React.FC = () => {
    return (
        <div style={{ maxWidth: 600, margin: '0 auto', padding: 20 }}>
            <h1>Exchange Rate Widget</h1>
            <ExchangeWidget />
            <WidgetList />
        </div>
    );
}

export default App;