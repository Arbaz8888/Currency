import { configureStore } from "@reduxjs/toolkit";  
import exchangeReducer from './exchangeSlice'; 

const store = configureStore({
    reducer: {
        exchange: exchangeReducer
    }
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;

export default store;

// export { indexreducer } from "./exchangeSlice"; // Uncomment if 'indexreducer' exists in exchangeSlice
export { fetchExchangeRates } from "./exchangeSlice";
export { exchangeReducer } from "./exchangeSlice";

