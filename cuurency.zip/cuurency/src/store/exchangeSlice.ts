import { createSlice, createAsyncThunk } from "@reduxjs/toolkit"
import axios from "axios"

export const fetchExchangeRates = createAsyncThunk(
    "exchange/fetchRates",
    async  ({base, targets}: {base: string, targets: string[]}) => {
        const API_KEY = "https://apilayer.com/marketplace/exchangerates_data-api"; ;
        const symbols = targets.join(",");

        const response = await axios.get(
            `https://api.apilayer.com/exchangerates_data/latest?base=${base}&symbols=${symbols}`,
            {
                headers: {
                    apikey: API_KEY
                }
            }
        );
        return { base, rates: response.data.rates } // Return base and rates
    }
)

const initialState = {
    base: "USD",
    rates: {} as Record<string, number>,
    loading: false,
    error: "",
}

const exchangeSlice = createSlice({
    name: "exchange",
    initialState,
    reducers: {
     /*   setBaseCurrency(state, action) {
            state.base = action.payload;
        },
        setExchangeRates(state, action) {
            state.rates = action.payload;
        } */
    },
    extraReducers: (builder) => {
        builder
            .addCase(fetchExchangeRates.pending, (state) => {
                state.loading = true;
                state.error = ""
            })
            .addCase(fetchExchangeRates.fulfilled, (state, action) => {
                state.loading = false;
                state.base = action.payload.base; // Set the base currency
                state.rates = action.payload.rates; // Set the rates
            })
            .addCase(fetchExchangeRates.rejected, (state, action) => {
                state.loading = false;
                state.error = action.error.message || "Failed to fetch exchange rates";
            });
    }
});
export const exchangeReducer = exchangeSlice.reducer;

export default exchangeSlice.reducer;
